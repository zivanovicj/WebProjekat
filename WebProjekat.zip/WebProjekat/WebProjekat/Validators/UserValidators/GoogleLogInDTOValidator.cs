﻿using FluentValidation;
using WebProjekat.DTO.UserDTO;

namespace WebProjekat.Validators.UserValidators
{
    public class GoogleLogInDTOValidator : AbstractValidator<GoogleLogInDTO>
    {
        public GoogleLogInDTOValidator()
        {
            RuleFor(x => x.Email).EmailAddress().WithMessage("Email is required.");
            RuleFor(x => x.FirstName).NotEmpty().WithMessage("FirstName is required.");
            RuleFor(x => x.LastName).NotEmpty().WithMessage("LastName is required.");
        }
    }
}
