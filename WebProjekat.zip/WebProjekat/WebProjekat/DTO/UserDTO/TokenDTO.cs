﻿using WebProjekat.Common;

namespace WebProjekat.DTO.UserDTO
{
    public class TokenDTO
    {
        public string Token { get; set; }
        public EUserType UserType { get; set; }
    }
}
