﻿namespace WebProjekat.DTO.ProductDTO
{
    public class ProductDTO
    {
        public int? ProductID { get; set; }
        public string ProductName { get; set; }
        public double Price { get; set; }
        public int Amount { get; set; }
        public string Description { get; set; }
    }
}
