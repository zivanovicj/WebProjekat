﻿namespace WebProjekat.DTO.OrderDTO
{
    public class OrderItemDTO
    {
        public int? OrderID { get; set; }
        public int ProductID { get; set; }
        public int Quantity { get; set; }
    }
}
