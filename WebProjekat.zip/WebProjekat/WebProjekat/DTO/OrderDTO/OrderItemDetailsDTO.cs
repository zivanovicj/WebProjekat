﻿namespace WebProjekat.DTO.OrderDTO
{
    public class OrderItemDetailsDTO
    {
        public string ProductName { get; set; }
        public double Price { get; set; }
        public int Quantity { get; set; }
    }
}
