﻿namespace WebProjekat.Common
{
    public enum EOrderStatus
    {
        DELIVERED,
        IN_PROGRESS,
        CANCELED
    }
}
