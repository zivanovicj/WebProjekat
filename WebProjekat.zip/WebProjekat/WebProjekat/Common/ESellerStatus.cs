﻿namespace WebProjekat.Common
{
    public enum ESellerStatus
    {
        VERIFIED,
        REJECTED,
        IN_PROCESS
    }
}
