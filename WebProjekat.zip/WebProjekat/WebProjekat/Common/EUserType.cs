﻿namespace WebProjekat.Common
{
    public enum EUserType
    {
        ADMIN,
        CUSTOMER,
        SELLER
    }
}
