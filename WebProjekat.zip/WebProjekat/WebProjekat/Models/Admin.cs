﻿namespace WebProjekat.Models
{
    public class Admin:User
    {
    }
}
